export const environment = {
  production: true,
   api_URL:'https://sistemaplacas.transitotungurahua.gob.ec',
};
