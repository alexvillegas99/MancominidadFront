export interface TipoVehiculo {
  id?: number;
  tipo: string;
}