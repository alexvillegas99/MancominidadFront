export interface Roles {
  id?: number;
  rol: string;
}