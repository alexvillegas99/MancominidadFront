export interface Usuario {
  id?: number;
  user: string;
  pass?: string;
  rol: string;
  nombre: string;
  estado:boolean;
}