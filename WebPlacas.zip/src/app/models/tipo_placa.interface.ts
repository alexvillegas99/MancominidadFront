export interface TipoPlaca {
  id?: number;
  tipo: string;
}