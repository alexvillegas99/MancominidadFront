# node v 14.0.5
# intall npm i
# dev : npm run dev
# start : npm run start